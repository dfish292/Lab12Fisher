﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab12Fisher
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearch.Text))
            {
                lblError.Text = "Please enter something into the search box";
                return;
            }
            var books = Books.GetBooks();
            var bookTitles = from bookItem in books
                             where bookItem.Title.Contains(txtSearch.Text)
                             orderby bookItem.Title
                             select bookItem;
            GridView1.DataSource = bookTitles;
            GridView1.DataBind();
            lblError.Text = null;
        }
    }
}